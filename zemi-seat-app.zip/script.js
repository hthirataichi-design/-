const members=["稲葉","金子","秋山","仲森","平本","井上","鈴木","岡崎","松井","五十嵐","星野","青沼","曾田","明戸","山本"];
const classroom=document.getElementById("classroom");
function shuffle(a){const b=[...a];for(let i=b.length-1;i>0;i--){const j=Math.floor(Math.random()*(i+1));[b[i],b[j]]=[b[j],b[i]];}return b;}
function createGroups(list){const g=[];for(let i=0;i<16;i+=4)g.push(list.slice(i,i+4));return g;}
function score(groups,pairs){let s=0;groups.forEach(g=>{const m=g.filter(x=>x!=="空席");for(let i=0;i<m.length;i++)for(let j=i+1;j<m.length;j++)if(pairs.includes([m[i],m[j]].sort().join("|")))s++;});return s;}
function build(groups){const p=[];groups.forEach(g=>{const m=g.filter(x=>x!=="空席");for(let i=0;i<m.length;i++)for(let j=i+1;j<m.length;j++)p.push([m[i],m[j]].sort().join("|"));});return p;}
function render(groups){classroom.innerHTML="";groups.forEach(g=>{const island=document.createElement("div");island.className="island";g.forEach(n=>{const s=document.createElement("div");s.className="seat";if(n==="空席")s.classList.add("empty");s.textContent=n;island.appendChild(s);});classroom.appendChild(island);});}
function generate(){const prev=JSON.parse(localStorage.getItem("pairHistory"))||[];let best=null,bestScore=1e9;for(let t=0;t<3000;t++){const g=createGroups(shuffle([...members,"空席"]));const sc=score(g,prev);if(sc<bestScore){bestScore=sc;best=g;}}render(best);localStorage.setItem("pairHistory",JSON.stringify(build(best)));}
document.getElementById("shuffleBtn").onclick=generate;
document.getElementById("resetBtn").onclick=()=>{localStorage.removeItem("pairHistory");alert("履歴を削除しました");};
generate();